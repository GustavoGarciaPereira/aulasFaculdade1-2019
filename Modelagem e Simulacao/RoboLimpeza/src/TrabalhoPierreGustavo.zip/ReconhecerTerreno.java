
/**
 *
 * @author Gustavo e Pierre
 */
public class ReconhecerTerreno {
    
    
    public void uploadMapa(){
        System.out.println("Mapa carregado!!");
    }
}
