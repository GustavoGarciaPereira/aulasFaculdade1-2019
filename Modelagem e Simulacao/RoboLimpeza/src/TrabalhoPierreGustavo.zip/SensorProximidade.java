
/**
 *
 * @author Gustavo e Pierre
 */
public class SensorProximidade {
    
    
    public void detectar(){
        System.out.println("andando!");
    }
      
}
