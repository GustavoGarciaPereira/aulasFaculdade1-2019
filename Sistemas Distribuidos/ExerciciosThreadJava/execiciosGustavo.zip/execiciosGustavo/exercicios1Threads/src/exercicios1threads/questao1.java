/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicios1threads;

/**
 *
 * @author usrlab01
 */
public class questao1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ThreadMostraNome t;
      
        for(int i=0;i<10;i++){
            t = new ThreadMostraNome(i+"");
            t.start();
        }
    }
    
}
